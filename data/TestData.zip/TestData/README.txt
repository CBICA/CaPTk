The data was prepared using the following mechanism:

- Dicom to nii conversion: dcm2nii (https://www.nitrc.org/projects/dcm2nii/)
- Denoising: SUSAN (https://link.springer.com/article/10.1007/s00371-006-0005-7)
- Bias correction: N4 bias correction (https://itk.org/Doxygen/html/classitk_1_1N4BiasFieldCorrectionImageFilter.html)
- Registration: FSL (https://fsl.fmrib.ox.ac.uk/fsl/fslwiki/FLIRT)
- Skull stripping: MUSE (https://www.med.upenn.edu/sbia/muse.html)

Note: This dataset can only used for CaPTk Beta versions from 'u' onwards. Any previous release of CaPTk should use sample data 1.4.0. 
